﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DanishMasters
{
    public class CoachData
    {
        public string Name;
        public int TD;
        public int CAS;
        public int Points;
        public int StuntyPoints;
        public List<Tournament> Tournaments;
        public string Type;
        public string Identifier { get { return Name + Type; } }
        public CountryBonuses ScamBonus;

        public CoachData(string name, Tournament tournament)
        {
            Name = name;
            Type = "DK";
            //TD = td;
            //CAS = cas;
            //Points = points;
            //StuntyPoints = stunty;
            ScamBonus = new CountryBonuses();
            Tournaments = new List<Tournament>();
            Tournaments.Add(tournament);
        }

        public int Count()
        {
            int count = 0;

            count = ScamBonus.Denmark == true ? count+= 1 : count;
            count = ScamBonus.Norway == true ? count += 1 : count;
            count = ScamBonus.Sweden == true ? count += 1 : count;
            count = ScamBonus.Finland == true ? count += 1 : count;

            return count;
        }
    }
}
