﻿namespace DanishMasters
{
    public class Tournament
    {

        public string TournamentName { get; set; }
        public string Race { get; set; }
        public string Casualties { get; set; }
        public string Points { get; set; }
        public string StuntyPoints { get; set; }
        public string TouchDowns { get; set; }
        public string Placement { get; set; }  
        public string Country { get; set; } = "Denmark";
    }
}