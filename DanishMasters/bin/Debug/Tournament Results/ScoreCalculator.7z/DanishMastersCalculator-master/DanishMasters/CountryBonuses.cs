﻿using System.Collections.Generic;
using System.Linq;

namespace DanishMasters
{
    public class CountryBonuses
    {
        public bool Denmark { get; set; }
        public bool Norway { get; set; }
        public bool Sweden { get; set; }
        public bool Finland { get; set; }

     
    }
}